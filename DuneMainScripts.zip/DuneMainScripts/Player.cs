using System.Collections;
using System.Collections.Generic;
using System.IO;
using Unity.Netcode;
using UnityEngine;
using Cards;
using Unity.VisualScripting;

public class Player : NetworkBehaviour, ISaveAndLoad
{
    public class PlayerData{
        public string color;
        public int waterNum;
        public int spiceNum;
        public int moneyNum;

        //角色
        public string character;
        //遊戲分數
        public int score;
        //說服力
        public int persuation;
        //戰鬥力
        public int combat;
        //影響力 white, red, purple, blue
        public List<int> influence = new List<int>{0,0,0,0};
        //手牌
        public List<int> handCards = new List<int>();
        //密牌
        public List<int> secretCards = new List<int>();
        //桌上的牌堆
        public List<int> cards = new List<int>();
        //棄牌
        public List<int> abandonedCards = new List<int>();
        //場上的牌
        public List<int> fieldCards = new List<int>();
        //特使到的地方
        public List<int> areas = new List<int>();
        //特使數量
        public int employees;
        //兵力 0: 陣營部隊 1: 場上部隊 2: 陣營無畏艦 3: 場上無畏艦
        public List<int> soldiers = new List<int>();
        //運輸船
        public int ship_mPos = 0;
        //科技
        public List<int> tech = new List<int>();
        //降價
        public int priceDown = 0;
        //有無加入最高委員會
        public bool inCommittee;
        //有無取得劍術大師
        public bool swordMaster;
        //有無取得黑特使
        public bool blackEmployee;
        //是否結束這輪(展示後)
        public bool roundFinished;
        //是否結束戰鬥密牌回合
        public bool combatRoundFinished;
        //是否有拿到圓盤
        public List<bool> allianceScore = new List<bool> {false, false, false, false};
        //科技翻牌
        public bool[] techcardsflip = new bool[4]{false, false, false, false};

        //special
        public bool Sspecial10 = false;
    }


    PlayerController playerController;

    //只在playercController被運用
    public int playersIndex;
    //檔案
    public PlayerData playerData;

    //幾號玩家
    public int number;
    //是否為自己的回合
    bool isMyTurn;
    //是否為展示回合
    bool isShowTurn;

    //是否可以出牌
    bool canSendCard;
    /// <summary>
    ///每張手牌在show階段是否被用過(handCardsIndex)
    /// </summary>
    List<bool> showCardIsUsed;
    //最多可以派幾隻兵
    int sendSoldierNum;
    int withdrawSoldierNum;
    int withdrawOtherSoldierNum;
    //是否有到戰鬥區域
    bool onBattleField;
    //是否可以買科技
    bool canBuyTech;
    //暫時降價
    int tempPriceDown;
    //狀態 abandon, normal, secret, destroy
    string handCardsStatus;
    //可以去的areas
    List<int> canGoAreas;
    //是否可以結束回合
    bool canFinishTurn;
    //用過黑特使
    bool blackEmployeeUsed;
    //棄牌次數
    int abandonOrDestroyTimes;
    //有沒有出戰鬥密牌
    bool ifSendCombatSecretCard;
    //所有弗雷曼人的義氣
    List<Effection> loyalty_blue;
    //一般牌special效果
    bool special29 = false;
    
    //科技special效果
    bool Tspecial3 = false;
    bool Tspecial3Used = false;

    //回合密牌special效果
    bool Sspecial14 = false, Sspecial14_2 = false;
    bool Sspecial15 = false;
    bool Sspecial17 = false;
    bool Sspecial18_2 = false;
    bool Sspecial22 = false;

    void Start()
    {
        //server端，先執行
        if(IsServer){
            playerController = GameObject.Find("PlayerController").GetComponent<PlayerController>();
        }

        //client端
        if(IsOwner){
            //創建時將自己加入好取得的地方
            GameObject.Find("Bridge").GetComponent<Bridge>().clientPlayer = gameObject.GetComponent<Player>();
            //從Join物件拿回號碼並給server端
            PlayerGiveNumberServerRpc(GameObject.Find("UI").transform.Find("Join").GetComponent<Join>().playerNum);
        }
    }

    #region 關於檔案

    public void Save()
    {
        File.WriteAllText(Application.dataPath + $"/Save/Player{number}Data.json", JsonUtility.ToJson(playerData));
    }
    /// <summary>
    /// 包含初始給資料
    /// </summary>
    public void Load()
    {
        playerData = JsonUtility.FromJson<PlayerData>(File.ReadAllText(Application.dataPath + $"/Save/Player{number}Data.json"));
    }
    public void LoadIfGameHasStarted()
    {
        playerData = JsonUtility.FromJson<PlayerData>(File.ReadAllText(Application.dataPath + $"/Save/Player{number}Data.json"));
        //給特使資料
        foreach(var eachArea in playerData.areas){
            playerController.GivePlayersEmployeeData(playerData.color, eachArea);
        }
        //給soldier資料
        playerController.GivePlayersSoldierData("soldier", playerData.color, "spawn", playerData.soldiers[0]+playerData.soldiers[1]);
        playerController.GivePlayersSoldierData("soldier", playerData.color, "moveOut", playerData.soldiers[1]);
        playerController.GivePlayersSoldierData("ship", playerData.color, "spawn", playerData.soldiers[2]+playerData.soldiers[3]);
        playerController.GivePlayersSoldierData("ship", playerData.color, "moveOut", playerData.soldiers[3]);
        //給分數圓柱資料
        playerController.GivePlayerScorePlateData(playerData.color, playerData.score);
        //給影響力方塊資料
        playerController.GivePlayerInfluenceBlockData(playerData.color, "white", playerData.influence[0]);
        playerController.GivePlayerInfluenceBlockData(playerData.color, "red", playerData.influence[1]);
        playerController.GivePlayerInfluenceBlockData(playerData.color, "purple", playerData.influence[2]);
        playerController.GivePlayerInfluenceBlockData(playerData.color, "blue", playerData.influence[3]);
        //給運艘船資料
        playerController.GivePlayerShip_MPlateData(playerData.color, playerData.ship_mPos);
        //給戰鬥標記資料
        playerController.GivePlayerCombatBlockData(playerData.color, playerData.combat);
        //科技
        for(int i = 0; i < playerData.tech.Count; i++){
            AddSelfTechClientRpc(playerData.tech[i]);
        }
    }
    public void NewData()
    {
        playerData = new PlayerData();
    }
    
    #endregion 關於檔案
    
    #region join game

    [ServerRpc]
    //玩家加入給server端號碼
    void PlayerGiveNumberServerRpc(int num)
    {
        number = num;
        if(!playerController.PlayerJoin(gameObject.GetComponent<Player>(), number))
        {
            PlayerNumberErrorClientRpc();
        }
    }
    [ClientRpc]
    void PlayerNumberErrorClientRpc()
    {
        GameObject.Find("OperateUI").GetComponent<OperateUI>().FillPlayerNumber();
    }

    //server隨機分配號碼用
    public void PlayerControllerGiveNumber(int n)
    {
        number = n;
    }
    //server分配顏色
    public void PlayerControllerGiveColor(string color){
        playerData.color = color;
    }
    #endregion join game

    #region in game

    //選角
    [ClientRpc]
    void ChooseCharacterClientRpc(int character1, int character2)
    {
        
    }
    //遊戲剛開始初始
    public void GameInit()
    {
        playerData.cards = Movement.Wash(Movement.CreateInitialCards());
        playerData.score = 1;
        playerData.waterNum = 1;
        SetResourceUIClientRpc("water", playerData.waterNum);
        SetResourceUIClientRpc("persuation", playerData.persuation);
        SetResourceUIClientRpc("spice", playerData.spiceNum);
        SetResourceUIClientRpc("money", playerData.moneyNum);
        playerData.employees = 2;
        playerData.swordMaster = false;
        playerData.blackEmployee = false;
        playerData.soldiers = new List<int>{3,0,0,0};
        playerController.GivePlayersSoldierData("soldier", playerData.color, "spawn", playerData.soldiers[0]);
        handCardsStatus = "normal";
        RoundInit();
        MovementTextClientRpc($"You are player{number} {playerData.color}");
        DrawCards(5);
        //ChooseCharacterClientRpc();
    }
    //每輪的初始
    public void RoundInit()
    {
        playerData.roundFinished = false;
        playerData.employees = 2;
        //劍術大師
        if(playerData.swordMaster) playerData.employees++;
        //黑特使
        if(playerData.blackEmployee){
            playerData.employees++;
            playerData.blackEmployee = false;
            blackEmployeeUsed = true;
        }
        isMyTurn = false;
        isShowTurn = false;
        canSendCard = false;
        playerData.areas = new List<int>();
        ClearEmployeesClientRpc();
        //科技翻牌
        playerData.techcardsflip = new bool[]{false, false, false, false};
        var techs = new List<int>{2,7,9,14};
        SelfTechs selfTechs = GameObject.Find("SelfTechs").GetComponent<SelfTechs>();
        foreach(var each in techs) selfTechs.FlipTech(each, true);
    }
    
    #region 關於回合
    /// <summary>
    /// (playerController呼叫)
    /// </summary>
    /// <param name="num"> 幾號玩家的回合</param>
    public void PlayerControllerCallPlayerTurn(int num)
    {
        string roundStatus = playerController.GetRoundStatus();
        if(roundStatus == "normal"){
            canFinishTurn = false;
            //正常回合
            if(num == number){
                canShow = true;
                isMyTurn = true;
                WhoseTurnTextClientRpc("Your Turn");
                if(playerData.employees > 0){
                    canSendCard = true;
                }
                sendSoldierNum = 0;
                withdrawSoldierNum = 0;
                withdrawOtherSoldierNum = 0;
                onBattleField = false;
                canBuyTech = false;
                tempPriceDown = 0;
                //高等會議
                if(playerData.inCommittee){
                    keptListOfEffections.Add(Effection.Gain("persuation", 2));
                    DoListOfEffections();
                }
            }else WhoseTurnTextClientRpc($"Player{num}'s Turn");
        }else if(roundStatus == "combat"){
            canShow = false;
            //戰鬥回合
            if(num == number){
                isMyTurn = true;
                ifSendCombatSecretCard = false;
                WhoseTurnTextClientRpc("Your Combat Turn");
            }else WhoseTurnTextClientRpc($"Player{num}'s Combat Turn");
        }
    }

    //告知玩家是誰的回合(UI)
    [ClientRpc]
    public void WhoseTurnTextClientRpc(string text)
    {
        if(!IsOwner) return;
        GameObject.Find("ShowUI").GetComponent<ShowUI>().WhoseTurnText(text);
    }

    //結束回合
    [ServerRpc]
    public void FinishBtnOnClickServerRpc()
    {
        string roundStatus = playerController.GetRoundStatus();
        if(isMyTurn){
            if(roundStatus == "combat"){
                //有沒有pass
                playerData.combatRoundFinished = !ifSendCombatSecretCard;
            }
            else if(!canFinishTurn && !Sspecial22) return;
            if(isShowTurn){
                playerData.roundFinished = true;
                isShowTurn = false;
                //將場上的牌加入廢牌堆
                playerData.abandonedCards.AddRange(playerData.fieldCards);
                playerData.fieldCards.Clear();
                //persuation歸零
                playerData.persuation = 0;
                SetResourceUIClientRpc("persuation", 0);
            }
            playerController.PlayerTurnFinished();
            isMyTurn = false;
            canBuyTech = false;
            //一般牌special 取消
            special29 = false;
            //科技special取消
            Tspecial3 = false;
            Tspecial3Used = false;
            //密牌特殊取消
            Sspecial14 = false;
            Sspecial14_2 = false;
            Sspecial15 = false;
            Sspecial17 = false;
            Sspecial18_2 = false;
            Sspecial22 = false;
        }
    }
    #endregion 關於回合

    #region 關於client輸入
    //兵
    [ServerRpc]
    public void Input_soldierDoubleSelectedServerRpc(string color, string type, string status)
    {
        if(!isMyTurn) return;
        if(color == playerData.color && status == "in" && type == "soldier"){
            if(sendSoldierNum > 0){
                playerController.GivePlayersSoldierData(type, color, "moveOut", 1);
                sendSoldierNum--;
                if(special29){
                    withdrawOtherSoldierNum++;
                }
            }
        }
        else if(color == playerData.color && status == "out" && type == "soldier"){
            if(withdrawSoldierNum > 0){
                playerController.GivePlayersSoldierData(type, color, "moveIn", 1);
                withdrawSoldierNum--;
            }
        }
        else if(color != playerData.color && status == "out" && type == "soldier"){
            if(withdrawOtherSoldierNum > 0){
                playerController.GivePlayersSoldierData(type, color, "moveIn", 1);
                withdrawOtherSoldierNum--;
            }
        }
    }

    [ClientRpc]
    void MovementTextClientRpc(string text)
    {
        if(!IsOwner) return;
        GameObject.Find("ShowUI").GetComponent<ShowUI>().MovementText(text);
    }
    //當卡被點擊
    [ServerRpc]
    public void Input_HandCardDoubleSelectedServerRpc(int handCardsIndex)
    {
        if(!isMyTurn || isShowTurn) return;
        if(handCardsStatus == "abandon"){
            AbandonOrDestroyHandCards("abandon", handCardsIndex);
        }
        else if(handCardsStatus == "destroy"){
            AbandonOrDestroyHandCards("destroy", handCardsIndex);
        }
        //密牌
        else if(handCardsStatus == "secret"){
            SendSecretCards(handCardsIndex);
        }
        //出牌
        else if(canSendCard){
            //檢查是否局面可派特使 欠@@@@@@
            /*if(playerData.handCards[handCardsIndex] < 8) canGoAreas = playerController.initialCards[playerData.handCards[handCardsIndex]].areas;
            else canGoAreas = playerController.initialCards[playerData.handCards[handCardsIndex]].areas;*/
            canSendCard = false;
            SendCards(handCardsIndex);
        }
    }
    //被選的那張展示卡保留的手牌索引值
    int selectedCardHandCardsIndex;
    [ServerRpc]
    public void Input_HandCardSelectedServerRpc(int handCardsIndex)
    {
        if(isMyTurn && isShowTurn && !showCardIsUsed[handCardsIndex]){
            int cardNum = playerData.handCards[handCardsIndex];
            selectedCardHandCardsIndex = handCardsIndex;
            //展示選擇
            NormalCards showCard;
            if(cardNum < 8) showCard = playerController.initialCards[cardNum];
            else showCard = playerController.empireCards[cardNum];
            foreach(var eachEffection in showCard.show){
                if(eachEffection.effection_name == "exchange" || eachEffection.effection_name == "or"){
                    DoEffection(eachEffection);
                }
            }
        }

    }

    [ServerRpc]
    public void Input_TechDoubleSelectedServerRpc(int pos){
        if(canBuyTech){
            int techCardNum = playerController.GetTech(pos);
            TestCards testCard = playerController.testCards[techCardNum];
            if(playerData.priceDown + playerData.spiceNum + tempPriceDown >= testCard.price){
                //扣香料
                if(tempPriceDown >= testCard.price){
                    tempPriceDown = 0;
                }else if(playerData.priceDown + tempPriceDown >= testCard.price){
                    playerData.priceDown -= testCard.price - tempPriceDown;
                    tempPriceDown = 0;
                }else{
                    playerData.spiceNum -= testCard.price - tempPriceDown - playerData.priceDown;
                    tempPriceDown = 0;
                    playerData.priceDown = 0;
                }
                playerData.tech.Add(techCardNum);
                playerController.BuyTech(pos);
                AddSelfTechClientRpc(techCardNum);
            }
        }
    }
    
    [ServerRpc]
    public void Input_FieldCardDoubleSelectedServerRpc(int pos){
        if(handCardsStatus == "destroy"){
            DestroyFieldCards(pos);
        }else if(isShowTurn && Tspecial3){
            DestroyFieldCards(pos);
        }
    }
    int Tspeical4KeptCardNum;
    /// <summary>
    /// 買卡
    /// </summary>
    [ServerRpc]
    public void Input_CardInMarketDoubleClickBuyACardServerRpc(int pos, int cardNum)
    {
        if(!isShowTurn && !Sspecial14 && !Sspecial14_2) return;
        NormalCards card = playerController.empireCards[cardNum-8];
        int price = card.price;
        if(playerData.persuation >= price){
            DoEffection(Effection.Gain("persuation", -price));
            playerController.BuyCard(pos);
            //科技4
            if(playerData.tech.Contains(4)){
                Tspeical4KeptCardNum = cardNum;
            }else{
                playerData.abandonedCards.Add(cardNum);
            }
            //購買獎勵
            if(card.buyReward != null){
                keptListOfEffections.AddRange(card.buyReward);
            }
            DoListOfEffections();
        }
    }
    
    [ServerRpc]
    public void Input_SelfTechDoubleClickServerRpc(int techNum){
        switch(techNum){
            case 1:
                keptListOfEffections.Add(new Effection("exchange", new List<string>{"spice","Tspecial1","","score"}, new List<int>{3,1,0,1}));
                DoListOfEffections(); break;
            case 2:
                if(!playerData.techcardsflip[0]){
                    keptListOfEffections.Add(new Effection("exchange", new List<string>{"money","","soldier"}, new List<int>{4,0,3}));
                    DoListOfEffections();
                    playerData.techcardsflip[0] = true;
                    GameObject.Find("SelfTechs").GetComponent<SelfTechs>().FlipTech(techNum, false);
                }
                break;
            case 3:
                if(playerData.persuation >= 6){
                    if(Tspecial3Used) break;
                    Tspecial3 = true;
                    Tspecial3Used = true;
                }break;
            case 5: break;



        }
    }
    
    #endregion 關於client輸入

    //同盟分數盤
    public void PlayerControllerGiveAllianceScore(string color, int alliance)
    {
        if(playerData.color == color){
            DoEffection(Effection.Gain("score", 1));
            playerData.allianceScore[alliance] = true;
        }else{
            if(playerData.allianceScore[alliance]){
                playerData.allianceScore[alliance] = false;
                DoEffection(Effection.Gain("score", -1));
            }
        }
    }
    
    public void PlayerControllerGiveCombatReward(List<Effection> effections)
    {
        keptListOfEffections = effections;
        DoListOfEffections();
    }
    
    #region 關於牌的效果
    //playercontroller呼叫執行終局密牌效果
    public void PlayerControllerCallDoEffection(Effection effection)
    {
        DoEffection(effection);
    }
    //抽卡
    void DrawCards(int num)
    {
        for(int i = 1; i <= num; i++){
            if(playerData.cards.Count == 0)
            {
                playerData.cards.AddRange(playerData.abandonedCards);
                playerData.cards = Movement.Wash(playerData.cards);
                playerData.abandonedCards.Clear();
            }
            playerData.handCards.Add(playerData.cards[0]);
            if(handCardsStatus == "normal")
                SpawnHandCardsClientRpc("normal", playerData.cards[0]);
            playerData.cards.RemoveAt(0);
        }
    }
    void DrawSecretCards(int num)
    {
        for(int i = 0; i < num; i++){
            playerData.secretCards.Add(playerController.DrawSecretCards());
        }
    }
    //一次一張，填標號
    [ClientRpc]
    void SpawnHandCardsClientRpc(string type, int num){
        if(!IsOwner) return;
        GameObject.Find("CardsManager").GetComponent<CardsManager>().Spawn(type, num);
    }
    //踢掉卡
    [ClientRpc]
    void KickHandCardsClientRpc(int index)
    {
        if(!IsOwner) return;
        GameObject.Find("CardsManager").GetComponent<CardsManager>().KickCard(index);
    }
    [ClientRpc]
    void ClearHandCardsClientRpc()
    {
        if(!IsOwner) return;
        GameObject.Find("CardsManager").GetComponent<CardsManager>().ClearCards();
    }
    void HandCardsShowNormalCards()
    {
        ClearHandCardsClientRpc();
        foreach(var each in playerData.handCards){
            SpawnHandCardsClientRpc("normal", each);
        }
    }
    void HandCardsShowSecretCards()
    {
        ClearHandCardsClientRpc();
        foreach(var each in playerData.secretCards){
            SpawnHandCardsClientRpc("secret", each);
        }
    }
    [ServerRpc]
    public void ChangeCardsServerRpc()
    {
        if(handCardsStatus == "secret"){
            HandCardsShowNormalCards();
            handCardsStatus = "normal";
        }else if(handCardsStatus == "normal"){
            HandCardsShowSecretCards();
            handCardsStatus = "secret";
        }
    }
    //type => abandon, destroy
    void AbandonOrDestroyHandCards(string type, int handCardsIndex)
    {
        NormalCards theCard;
        //59 為特殊，僅有銷毀功能
        if(playerData.handCards[handCardsIndex] > 7 && !(playerData.handCards[handCardsIndex] == 59 && type == "abandon")){
            theCard = playerController.empireCards[playerData.handCards[handCardsIndex]-8];
            if(theCard.haveAbandonedEffection){
                keptListOfEffections.AddRange(theCard.show);
                DoListOfEffections();
            }
        }
        if(type == "abandon"){
            playerData.abandonedCards.Add(playerData.handCards[handCardsIndex]);
        }
        playerData.handCards.RemoveAt(handCardsIndex);
        KickHandCardsClientRpc(handCardsIndex);
        //剩餘次數，如果為零就恢復正常
        if(abandonOrDestroyTimes > 1){
            abandonOrDestroyTimes--;
        }
        if(abandonOrDestroyTimes == 0){
            handCardsStatus = "normal";
        }
    }
    void DestroyFieldCards(int pos){
        if(playerData.fieldCards[pos] > 7){
            NormalCards theCard = playerController.empireCards[playerData.fieldCards[pos]];
            if(theCard.haveAbandonedEffection){
                keptListOfEffections.AddRange(theCard.show);
                DoListOfEffections();
            }
        }
        playerData.fieldCards.RemoveAt(pos);
        KickFieldCardsClientRpc(pos);
        if(abandonOrDestroyTimes > 1){
            abandonOrDestroyTimes--;
        }
        if(abandonOrDestroyTimes == 0){
            handCardsStatus = "normal";
        }
    }
    
    Effection keptEffection;
    List<Effection> keptListOfEffections = new List<Effection>();
    bool increaseInfluence;
    //對Effection進行初步處理，choice => send, show, abandoned
    void DoEffection(Effection effection)
    {
        switch(effection.effection_name)
        {
            case "gain":
                switch(effection.item_name[0])
                {
                    #region normal gain
                    case "water":
                        playerData.waterNum += effection.num[0];
                        SetResourceUIClientRpc("water", playerData.waterNum);
                        break;
                    case "spice":
                        playerData.spiceNum += effection.num[0];
                        SetResourceUIClientRpc("spice", playerData.spiceNum);
                        break;
                    case "money":
                        playerData.moneyNum += effection.num[0];
                        SetResourceUIClientRpc("money", playerData.moneyNum);
                        break;
                    case "soldier":
                        playerData.soldiers[0] += effection.num[0];
                        playerController.GivePlayersSoldierData("soldier", playerData.color, "spawn", effection.num[0]);
                        if(effection.soldierCanSend && onBattleField){
                            sendSoldierNum += effection.num[0];
                        }
                        break;
                    case "combat":
                        if(playerData.soldiers[1] == 0 && playerData.soldiers[3] == 0) break;
                        playerData.combat += effection.num[0];
                        playerController.GivePlayerCombatBlockData(playerData.color, playerData.combat);
                        break;
                    case "ship":
                        playerData.soldiers[1] += effection.num[0];
                        playerController.GivePlayersSoldierData("ship", playerData.color, "spawn", effection.num[0]);
                        break;
                    case "ship_m":
                        AskClientRpc("Do you want to raise or lower the ship?", "upOrDown", effection.num[0], 22);
                        break;
                    case "card":
                        DrawCards(effection.num[0]);
                        break;
                    case "secretCard":
                        DrawSecretCards(effection.num[0]);
                        break;
                    case "blackEmployee":
                        if(playerController.TakeBlackEmployee()){
                            playerData.blackEmployee = true;
                        }
                        break;
                    case "white":                        
                        if(playerData.influence[0] != 6) playerData.influence[0] += effection.num[0];
                        if(playerData.influence[0] == 2) DoEffection(Effection.Gain("score", 1));
                        if(playerData.influence[0] == 4) DoEffection(Effection.Gain("soldier", 2));
                        if(playerData.influence[0] >= 4) playerController.TakeAllianceScore(playerData.color, 0, playerData.influence[0]);
                        playerController.GivePlayerInfluenceBlockData(playerData.color, "white", playerData.influence[0]);
                        break;
                    case "red":
                        if(playerData.influence[1] != 6) playerData.influence[1] += effection.num[0];
                        if(playerData.influence[1] == 2) DoEffection(Effection.Gain("score", 1));
                        if(playerData.influence[1] == 4) DoEffection(Effection.Gain("money", 3));
                        if(playerData.influence[1] >= 4) playerController.TakeAllianceScore(playerData.color, 0, playerData.influence[1]);
                        playerController.GivePlayerInfluenceBlockData(playerData.color, "red", playerData.influence[1]);
                        break;
                    case "purple":
                        if(playerData.influence[2] != 6) playerData.influence[2] += effection.num[0];
                        if(playerData.influence[2] == 2) DoEffection(Effection.Gain("score", 1));
                        if(playerData.influence[2] == 4) DoEffection(Effection.Gain("secretCard", 1));
                        if(playerData.influence[2] >= 4) playerController.TakeAllianceScore(playerData.color, 0, playerData.influence[2]);
                        playerController.GivePlayerInfluenceBlockData(playerData.color, "purple", playerData.influence[2]);
                        break;
                    case "blue":
                        if(playerData.influence[3] != 6) playerData.influence[3] += effection.num[0];
                        if(playerData.influence[3] == 2) DoEffection(Effection.Gain("score", 1));
                        if(playerData.influence[3] == 4) DoEffection(Effection.Gain("water", 1));
                        if(playerData.influence[3] >= 4) playerController.TakeAllianceScore(playerData.color, 0, playerData.influence[3]);
                        playerController.GivePlayerInfluenceBlockData(playerData.color, "blue", playerData.influence[3]);
                        break;
                    case "anyColor":
                        increaseInfluence = true;
                        AskClientRpc("Which faction do you want to increase the influence of?", "influence", effection.num[0], 22);
                        break;
                    case "anyColorDown":
                        increaseInfluence = false;
                        AskClientRpc("Which faction do you want to decrease the influence of?", "influence", effection.num[0], 22);
                        break;
                    case "score":
                        playerData.score += effection.num[0];
                        playerController.GivePlayerScorePlateData(playerData.color, playerData.score);
                        break;
                    case "persuation":
                        playerData.persuation += effection.num[0];
                        SetResourceUIClientRpc("persuation", playerData.persuation);
                        break;
                    case "tech":
                        AskClientRpc("Do you want to buy a tecnology?", "yesOrNo", 1, 22);
                        tempPriceDown += effection.num[0];
                        break;
                    case "priceDown":
                        playerData.priceDown += effection.num[0];
                        break;
                    case "abandon":
                        if(handCardsStatus == "secret") ChangeCardsServerRpc();
                        handCardsStatus = "abandon";
                        abandonOrDestroyTimes = effection.num[0];
                        AskClientRpc("Choose a card to abandon", "text", 1, 25);
                        break;
                    case "destroy":
                        if(handCardsStatus == "secret") ChangeCardsServerRpc();
                        handCardsStatus = "destroy";
                        abandonOrDestroyTimes = effection.num[0];
                        AskClientRpc("Choose a card to destroy", "text", 1, 25);
                        break;
                    case "destroySelf":
                        KickFieldCardsClientRpc(playerData.fieldCards.Count-1);
                        playerData.fieldCards.RemoveAt(playerData.fieldCards.Count-1);
                        break;
                    #endregion normal gain
                    #region secretCardSpeical gain
                    case "Sspecial1":
                        playerData.cards.AddRange(playerData.abandonedCards);
                        playerData.abandonedCards.Clear();
                        playerData.cards = Movement.Wash(playerData.cards);
                        DoEffection(Effection.Gain("card", 1));
                        break;
                    case "Sspecial3":
                        if(isShowTurn){
                            //AskClientRpc("number")
                        }break;
                    case "Sspecial4":
                        break;
                    case "Sspecial5":
                        break;
                    case "Sspecial7":
                        //欠
                        break;
                    case "Sspecial8":
                        //欠
                        break;
                    case "Sspecial9":
                        var hasAdded = new List<bool>{false, false, false, false};
                        foreach(var each in playerData.areas){
                            for(int i = 1; i <= 4; i++){
                                if((each == i*2-1 || each == i*2 ) && hasAdded[i-1] == false){
                                    if(i == 1) DoEffection(Effection.Gain("white", 1));
                                    else if(i == 2) DoEffection(Effection.Gain("red", 1));
                                    else if(i == 3) DoEffection(Effection.Gain("purple", 1));
                                    else DoEffection(Effection.Gain("blue", 1));
                                    hasAdded[i-1] = true;
                                }
                            }
                        }
                        break;
                    case "Sspecial10":
                        playerData.Sspecial10 = true; break;
                    case "Ssepical12":
                        //欠
                        break;
                    case "Sspeical14":
                        Sspecial14 = true; break;
                    case "Sspecial14.2":
                        Sspecial14_2 = true; break;
                    case "Sspecial15":
                        DoEffection(Effection.Gain("persuation", 1));
                        Sspecial15 = true; break;
                    case "Sspecial17":
                        Sspecial17 = true; break;
                    case "Sspecial18":
                        if(playerData.soldiers[0] > 0){
                            playerData.soldiers[0]--;
                            playerController.GivePlayersSoldierData("soldier", playerData.color, "despawnIn", 1);
                        }else{
                            playerData.soldiers[1]--;
                            playerController.GivePlayersSoldierData("soldier", playerData.color, "despawnOut", 1);
                        } break;
                    case "Sspecial18.2":
                        Sspecial18_2 = true; break;
                    case "Sspecial22":
                        Effection.Gain("card", 1);
                        Sspecial22 = true; break;
                    case "Sspecial23":
                        break;
                    case "Sspecial24":
                        if(playerData.soldiers[1] + playerData.soldiers[3] >= 4){
                            keptListOfEffections.Add(Effection.Gain("ship_m", 1));
                            DoListOfEffections();
                        } break;
                    case "Sspecial26":
                        bool alliance = false;
                        foreach(var each in playerData.influence){
                            if(each >= 4) alliance = true;
                        }
                        if(alliance){
                            keptListOfEffections.Add(new Effection("exchange", new List<string>{"spice","","combat"}, new List<int>{2,0,7}));
                            DoListOfEffections();
                        } break;
                    case "Sspecial27":
                        break;
                    case "Sspecial28":
                        break;
                    case "Sspecial29":
                        break;
                    //case ""
                        


                    //case 
                    #endregion secretCardSpeical gain
                }
                //接續著做
                DoListOfEffections();
                break;
            case "exchange":
                //加檢查
                if(!ExchangeCheck(effection)){
                    break;
                }
                //詢問
                keptEffection = effection;
                AskClientRpc("Do you want to change?", "This", 1, 28);
                break;
            case "or":
                //檢查略，拆解後如果有exchange會再檢查
                keptEffection = effection;
                //詢問
                AskClientRpc("Which do you want to choose?", "This2", 1, 22);
                break;
            #region normalCards special
            case "special13":
                sendSoldierNum += 3;
                DoListOfEffections(); break;
            case "special15":
                playerData.soldiers[1] -= 3;
                playerData.soldiers[0] += 3;
                playerController.GivePlayersSoldierData("soldier", playerData.color, "moveIn", 3);
                DoListOfEffections(); break;
            case "special16":
                playerData.soldiers[0] += 2;
                sendSoldierNum += 2;
                DoListOfEffections(); break;
            case "special17.2":
                if(playerData.influence[1] >= 4) keptListOfEffections.Insert(0, Effection.Gain("spice", 3));
                DoListOfEffections(); break;
            case "special18":
                bool ifTrue = false;
                foreach(var each in playerData.fieldCards){
                    if(each > 7){
                        if(playerController.empireCards[each-8].alliance.Contains("purple")){
                            ifTrue = true;
                        }
                    }
                }
                if(ifTrue){
                    keptListOfEffections.Add(Effection.Gain("anyColor", 1));
                }
                DoListOfEffections(); break;
            case "special22":
                withdrawSoldierNum += 2;
                DoListOfEffections(); break;
            case "special29":
                special29 = true;
                DoListOfEffections(); break;
            
            #endregion normalCards special
            case "Tspecial4":
                keptEffection = new Effection("Tspecial4",null,null);
                AskClientRpc("Do you want to put it in the discard pile or the card pile?", "Tspecial4", 1, 22);
                break;
        }
    }
    //檢查是否可以做事
    bool ExchangeCheck(Effection effection)
    {
        int i = 0;
        foreach(var each in effection.item_name){
            if(each == "") return true;
            switch(each)
            {
                case "water":
                    if(playerData.waterNum < effection.num[i]) return false;
                    break;
                case "spice":
                    if(playerData.spiceNum < effection.num[i]) return false;
                    break;
                case "money":
                    if(playerData.moneyNum < effection.num[i]) return false;
                    break;
                case "anyColorDown":
                    foreach(var camp in playerData.influence){
                        if(camp != 0) break;
                    }
                    return false;
                case "special15":
                    if(playerData.soldiers[1] < 3) return false;
                    break;
                case "special35":
                    break;
                case "special52":
                    if(playerData.influence[1] < 4) return false;
                    if(playerData.spiceNum < effection.num[i]) return false;
                    break;
                //密牌
                case "Sspecial18":
                    if(playerData.soldiers[0] == 0 && playerData.soldiers[1] == 0) return false;
                    break;
            }
            i++;
        }
        return true;
    }
    
    //出密牌
    void SendSecretCards(int index)
    {
        string roundStatus = playerController.GetRoundStatus();
        SecretCards secretCard = playerController.secretCards[playerData.secretCards[index]];
        if(roundStatus == "normal"){
            if(secretCard.type == "combat" || secretCard.type == "endGame" || secretCard.type == "normalOrEndGame") return;
        }else if(roundStatus == "combat"){
            if(secretCard.type == "normal" || secretCard.type == "endGame" || secretCard.type == "combatOrEndGame") return;
            ifSendCombatSecretCard = true;
        }else if(roundStatus == "endGame"){
            if(secretCard.type == "normal" || secretCard.type == "combat" || secretCard.type == "normalOrCombat") return;
        }
        playerData.secretCards.RemoveAt(index);
        KickHandCardsClientRpc(index);
        DoEffection(secretCard.effection);
    }
    
    //出的牌
    NormalCards sendCard;
    int sendCardNum;
    /// <summary>
    /// 輸入在玩家手牌的索引值
    /// </summary>
    void SendCards(int index)
    {
        canShow = false;

        int cardNum = playerData.handCards[index];
        sendCardNum = cardNum;
        //出牌資訊更改
        playerData.handCards.RemoveAt(index);
        KickHandCardsClientRpc(index);
        playerData.fieldCards.Add(cardNum);
        SpawnFieldCardsClientRpc(playerData.fieldCards.Count-1, cardNum);
        //向playerController取得牌
        if(cardNum < 8) sendCard = playerController.initialCards[cardNum-1];
        else sendCard = playerController.empireCards[cardNum-8];
        //執行弗雷曼契約
        if(sendCard.loyalty.Count != 0){
            bool blueOnField = false;
            foreach(var each in playerData.fieldCards){
                if(each < 8) continue;
                if(playerController.empireCards[each].loyalty.Count != 0){
                    blueOnField = true;
                }
            }
            if(blueOnField){
                keptListOfEffections = loyalty_blue;
                loyalty_blue.Clear();
                keptListOfEffections.AddRange(sendCard.loyalty);
                DoListOfEffections();
            }else{
                loyalty_blue.AddRange(sendCard.loyalty);
            }
        }
        //派特使
        AskToSendEmployeeClientRpc();
        //中斷，剩下在sendEmployeeServerRpc()
    }
    //派特使
    [ServerRpc]
    public void SendEmployeeServerRpc(int areaNum)
    {
        var areas = sendCard.areas;
        if(Sspecial17) areas.AddRange(new List<int>{1,2,3,4,5,6,7,8});
        bool isSuccessful = false;
        //和別人在同一地區
        if(((sendCard.areasRepeated || playerData.Sspecial10) && areas.Contains(areaNum)) || 
        //和別人在不同地區
        (playerController.GetAvailableAreas().Contains(areaNum) && areas.Contains(areaNum))){
            playerData.Sspecial10 = false;
            //地區條件檢查並直接扣除費用
            switch(areaNum){
                case 1:
                    if(playerData.spiceNum >= 4){
                        isSuccessful = true;
                        keptListOfEffections.Add(Effection.Gain("spice", -4));
                    }break;
                case 3:
                    if(sendCardNum == 17 && playerData.spiceNum >= 4){
                        isSuccessful = true;
                        keptListOfEffections.Add(Effection.Gain("spice", -4));
                        break;
                    }
                    if(playerData.spiceNum >= 6){
                        isSuccessful = true;
                        keptListOfEffections.Add(Effection.Gain("spice", -6));
                    }break;
                case 5:
                    if(playerData.spiceNum >= 2){
                        isSuccessful = true;
                        keptListOfEffections.Add(Effection.Gain("spice", -2));
                    }break;
                case 7:
                    if(playerData.waterNum >= 1){
                        isSuccessful = true;
                        keptListOfEffections.Add(Effection.Gain("water", -1));
                    }break;
                case 9:
                    if(playerData.moneyNum >= 5){
                        isSuccessful = true;
                        keptListOfEffections.Add(Effection.Gain("money", -5));
                    }break;
                case 10:
                    if(playerData.moneyNum >= 2){
                        isSuccessful = true;
                        keptListOfEffections.Add(Effection.Gain("money", -2));
                    }break;
                case 11:
                    if(playerData.moneyNum >= 8){
                        isSuccessful = true;
                        keptListOfEffections.Add(Effection.Gain("money", -8));
                    }break;
                case 13:
                    if(playerData.moneyNum >= 3){
                        isSuccessful = true;
                        keptListOfEffections.Add(Effection.Gain("money", -3));
                    }break;
                case 14:
                    if(playerData.influence[1] >= 2){
                        isSuccessful = true;
                    }break;
                case 16:
                    if(playerData.waterNum >= 2){
                        isSuccessful = true;
                        keptListOfEffections.Add(Effection.Gain("water", -2));
                    }break;
                case 17:
                    if(playerData.waterNum >= 1){
                        isSuccessful = true;
                        keptListOfEffections.Add(Effection.Gain("water", -1));
                    }break;
                case 19:
                    if(playerData.influence[3] >= 2){
                        isSuccessful = true;
                    }break;
                case 20:
                    if(playerData.waterNum >= 2){
                        isSuccessful = true;
                        keptListOfEffections.Add(Effection.Gain("water", -2));
                    }break;
                default:
                    isSuccessful = true;
                    break;
            }
            DoListOfEffections();
        }

        if(isSuccessful){
            if(playerData.employees == 1 && blackEmployeeUsed){
                //黑特使 欠@@@@
                blackEmployeeUsed = false;
            }
            //扣除特使
            playerData.employees--;
            //特使送出
            playerData.areas.Add(areaNum);
            playerController.GivePlayersEmployeeData(playerData.color, areaNum);
            //可不可以派兵
            if(new List<int>{3,7,8,16,17,18,19,20,21,22}.Contains(areaNum))
                onBattleField = true;
                sendSoldierNum += 2;
            //影響力
            int influenceNum = 1;
            //一般牌special
            if(sendCardNum == 10) influenceNum++;
            //密牌special
            if(Sspecial18_2) influenceNum++;
            //特使做事
            switch(areaNum){
                case 1:
                    keptListOfEffections.Add(Effection.Gain("white", influenceNum));
                    keptListOfEffections.Add(Effection.Gain("money", 5));
                    keptListOfEffections.Add(Effection.Gain("soldier", 2));
                    keptListOfEffections.Add(Effection.Gain("secretCard", 1));
                    break;
                case 2:
                    keptListOfEffections.Add(Effection.Gain("white", influenceNum));
                    keptListOfEffections.Add(Effection.Gain("money", 2));
                    break;
                case 3:
                    keptListOfEffections.Add(Effection.Gain("red", influenceNum));
                    keptListOfEffections.Add(new Effection("gain", new List<string>{"soldier"},new List<int>{5}){soldierCanSend = true});
                    keptListOfEffections.Add(Effection.Gain("water", 2));
                    break;
                case 4:
                    keptListOfEffections.Add(Effection.Gain("red", influenceNum));
                    break;
                case 5:
                    keptListOfEffections.Add(Effection.Gain("purple", influenceNum));
                    keptListOfEffections.Add(Effection.Gain("abandon", 1));
                    keptListOfEffections.Add(Effection.Gain("card", 2));
                    break;
                case 6:
                    keptListOfEffections.Add(Effection.Gain("purple", influenceNum));
                    keptListOfEffections.Add(Effection.Gain("secretCard", 1));
                    break;
                case 7:
                    keptListOfEffections.Add(Effection.Gain("blue", influenceNum));
                    keptListOfEffections.Add(new Effection("gain", new List<string>{"soldier"},new List<int>{2}){soldierCanSend = true});
                    break;
                case 8:
                    keptListOfEffections.Add(Effection.Gain("blue", influenceNum));
                    keptListOfEffections.Add(Effection.Gain("water", 1)); break;
                case 9:
                    playerData.inCommittee = true; break;
                case 10:
                    keptListOfEffections.Add(Effection.Gain("card", 1));
                    keptListOfEffections.Add(Effection.Gain("blackEmployee", 1));
                    break;
                case 11:
                    playerData.swordMaster = true; break;
                case 12:
                    keptListOfEffections.Add(Effection.Gain("persuation", 1));
                    keptListOfEffections.Add(new Effection("or",null,null){
                        or = new List<Effection>{Effection.Gain("tech", 1), Effection.Gain("priceDown", 1)}
                    });
                    break;
                case 13:
                    keptListOfEffections.Add(Effection.Gain("ship", 1));
                    keptListOfEffections.Add(Effection.Gain("tech", 0));
                    break;
                case 14:
                    keptListOfEffections.Add(Effection.Gain("ship_m", 2));
                    break;
                case 15:
                    keptListOfEffections.Add(Effection.Gain("money", 1));
                    keptListOfEffections.Add(Effection.Gain("ship_m", 1));
                    break;
                case 16:
                    keptListOfEffections.Add(Effection.Gain("spice", 3 + playerController.TakeSpice(16))); break;
                case 17:
                    keptListOfEffections.Add(Effection.Gain("spice", 2 + playerController.TakeSpice(17))); break;
                case 18:
                    keptListOfEffections.Add(Effection.Gain("spice", 1 + playerController.TakeSpice(18))); break;
                case 19:
                    keptListOfEffections.Add(new Effection("gain", new List<string>{"soldier"}, new List<int>{1}){soldierCanSend=true});
                    keptListOfEffections.Add(Effection.Gain("water", 1)); break;
                case 20:
                    keptListOfEffections.Add(Effection.Gain("card", 3)); break;
                case 21:
                    keptListOfEffections.Add(new Effection("gain", new List<string>{"soldier"}, new List<int>{1}){soldierCanSend=true});
                    keptListOfEffections.Add(Effection.Gain("secretCard", 1)); break;
                case 22:
                    keptListOfEffections.Add(new Effection("gain", new List<string>{"soldier"}, new List<int>{1}){soldierCanSend=true});
                    keptListOfEffections.Add(Effection.Gain("card", 1)); break;
            }
            DoListOfEffections();
            //特使框
            keptListOfEffections.AddRange(sendCard.send);
            DoListOfEffections();
            onBattleField = false;
            //可以結束了
            canFinishTurn = true;
        }
        //選擇的地區無法去
        else{
            AskToSendEmployeeClientRpc();
        }

    }
    
    
    //做List的Effection時使用 => keptListOfEffections
    void DoListOfEffections(){
        if(keptListOfEffections.Count == 0){
            return;
        }
        Effection effection = keptListOfEffections[0];
        keptListOfEffections.RemoveAt(0);
        DoEffection(effection);
    }
    
    //展示
    //是否可以展示
    bool canShow = false;
    [ServerRpc]
    public void ShowCardsServerRpc()
    {
        //進入展示階段
        if(isMyTurn && !isShowTurn && canShow){
            isShowTurn = true;
            canSendCard = false;
        }else return;

        NormalCards showCard;
        showCardIsUsed = new List<bool>();
        //先拿取可得到的
        foreach(var eachCard in playerData.handCards){
            showCardIsUsed.Add(false);
            if(eachCard < 8) showCard = playerController.initialCards[eachCard-1];
            else showCard = playerController.empireCards[eachCard-8];
            foreach(var eachEffection in showCard.show){
                //科技5
                if(playerData.tech.Contains(5)){
                    if(eachEffection.effection_name == "gain" && eachEffection.item_name[0] == "combat"){
                        keptListOfEffections.Add(Effection.Gain("combat", 1));
                    }
                }
                if(eachEffection.effection_name != "exchange" && eachEffection.effection_name != "or"){
                    keptListOfEffections.Add(eachEffection);
                }
            }
            DoListOfEffections();
        }
        //可以結束了
        canFinishTurn = true;
    }

    //詢問(右上角)
    [ClientRpc]
    void AskClientRpc(string text, string type, int num, int fontSize)
    {
        if(!IsOwner) return;
        GameObject.Find("OperateUI").GetComponent<OperateUI>().SetOptions(text, type, num, fontSize);
    }
    /// <summary>
    /// 回應AskClientRpc的答案
    /// </summary>
    /// <param name="type"> choose, number </param>
    /// <param name="reply"> 0:no 1:yes(第一項) 2:yes(第二項) ， upOrDown: 0up, 1down</param>
    [ServerRpc]
    public void ReplyServerRpc(string type, int reply)
    {
        if(type == "yesOrNo"){
            //科技 
            canBuyTech = true;
        }
        else if(type == "choose"){
            if(reply != 0)
            {
                //將在展示階段使用效果後的卡標記
                if(isShowTurn) showCardIsUsed[selectedCardHandCardsIndex] = true;
                //執行
                if(keptEffection.effection_name == "Tspecial4"){
                    if(reply == 1)
                        playerData.abandonedCards.Add(Tspeical4KeptCardNum);
                    else
                        playerData.cards.Insert(Tspeical4KeptCardNum, 0);
                    DoListOfEffections(); return;
                }
                else if(keptEffection.effection_name == "or"){
                    if(ExchangeCheck(keptEffection.or[reply-1]))
                    {
                        keptEffection = keptEffection.or[reply-1];
                    }else DoOptionAgainClientRpc();
                }

                //對exchange拆解
                if(keptEffection.effection_name == "exchange"){
                    int i = 0;
                    int plusOrMinus = -1;
                    foreach(var each in keptEffection.item_name)
                    {
                        //要新增特殊
                        if(each == "")
                        {
                            plusOrMinus = 1;
                            i++;
                            continue;
                        }
                        keptListOfEffections.Add(Effection.Gain(each, keptEffection.num[i] * plusOrMinus));
                        i++;
                    }
                    DoListOfEffections();
                }
                //不是exchange而是其他效果
                else
                    DoEffection(keptEffection);
            }
        }
        else if(type == "soldierNumber"){
            if(playerData.soldiers[0] >= reply && sendSoldierNum >= reply){
                playerData.soldiers[0] -= reply;
                playerData.soldiers[1] += reply;
                sendSoldierNum -= reply;
                playerController.GivePlayersSoldierData("soldier", playerData.color, "moveOut", reply);
            }else DoOptionAgainClientRpc();
        }
        else if(type == "shipNumber"){
            if(playerData.soldiers[2] > reply && sendSoldierNum > reply){
                playerData.soldiers[2] -= reply;
                playerData.soldiers[3] += reply;
                sendSoldierNum -= reply;
                playerController.GivePlayersSoldierData("ship", playerData.color, "moveOut", reply);
            }else DoOptionAgainClientRpc();
        }
        else if(type == "withdraw"){
            if(playerData.soldiers[1] >= reply && withdrawSoldierNum >= reply){
                playerData.soldiers[1] -= reply;
                playerData.soldiers[0] += reply;
                withdrawSoldierNum -= reply;
                playerController.GivePlayersSoldierData("soldier", playerData.color, "moveIn", reply);
            }else DoOptionAgainClientRpc();
        }
        else if(type == "upOrDown"){
            if(reply == 0){
                if(playerData.ship_mPos > 0){
                    //執行取得獎勵
                    while(playerData.ship_mPos != 0){
                        if(playerData.ship_mPos == 3){
                            keptListOfEffections.Add(Effection.Gain("tech", 2));
                        }else if(playerData.ship_mPos == 2){
                            keptListOfEffections.Add(Effection.Gain("soldier", 2));
                            keptListOfEffections.Add(Effection.Gain("anyColor", 1));
                        }else{
                            keptListOfEffections.Add(new Effection("or",null,null){
                                or = new List<Effection>{new Effection("ship_mSpecial",null,null), Effection.Gain("spice", 2)}
                            });
                        }
                        playerData.ship_mPos--;
                    }
                    DoListOfEffections();
                    playerController.GivePlayerShip_MPlateData(playerData.color, 0);
                }else{
                    DoOptionAgainClientRpc();
                }
            }else{
                if(reply != 3){
                    DoOptionAgainClientRpc();
                }else{
                    playerData.ship_mPos++;
                    playerController.GivePlayerScorePlateData(playerData.color, playerData.ship_mPos);
                }
            }
        }
        else if(type == "influence"){
            if(increaseInfluence){
                playerData.influence[number]++;
            }
            else{
                if(playerData.influence[number] == 0){
                    DoOptionAgainClientRpc();
                }else{
                    playerData.influence[number]--;
                }
            }
        }
        //詢問後要做完可能有剩下的effections
        DoListOfEffections();
    }
    //再問一次
    [ClientRpc]
    void DoOptionAgainClientRpc()
    {
        if(!IsOwner) return;
        GameObject.Find("OperateUI").GetComponent<OperateUI>().number++;
    }
    
    /// <summary>
    /// 問client端派特使到哪
    /// </summary>
    /// <param name="area"> 可以去的地方 </param> 
    [ClientRpc]
    void AskToSendEmployeeClientRpc()
    {
        if(!IsOwner) return;
        //使client可以派特使
        GameObject.Find("AreaBlocks").GetComponent<AreaBlocks>().OpenSendEmployee();
    }
    
    #endregion 關於牌的效果

    public void CountCombat()
    {
        int addCombatNum = 0;
        //戰場上
        addCombatNum += playerData.soldiers[1] * 2;
        addCombatNum += playerData.soldiers[3] * 3;
        //科技

        keptListOfEffections.Add(Effection.Gain("combat", addCombatNum));
        DoListOfEffections();
    }
    
    #region 關於場上物件的資料傳遞
    //清除物件，reload時使用
    [ClientRpc]
    public void ClearObjectsClientRpc()
    {
        if(!IsOwner) return;
        GameObject.Find("Employees").GetComponent<Employees>().ClearEmployees();
        GameObject.Find("Soldiers").GetComponent<Soldiers>().ClearSoldiers();
    }
    
    //初始生成，reload和gamestart時使用
    [ClientRpc]
    public void InitObjectsClientRpc()
    {
        if(!IsOwner) return;
        GameObject.Find("CardsMarket").GetComponent<CardsMarket>().CardsInMarketInit();
        GameObject.Find("Ship_MPlates").GetComponent<Ship_MPlates>().SpawnAllShip_MPlate();
        GameObject.Find("Influence").GetComponent<Influence>().InitInfluenceBlock();
        GameObject.Find("ScorePlates").GetComponent<ScorePlates>().InitScorePlate();
        GameObject.Find("CombatBlocks").GetComponent<CombatBlocks>().InitCombatBlock();
        GameObject.Find("TechCards").GetComponent<TechCards>().InitTechCards();
        GameObject.Find("FieldCards").GetComponent<FieldCards>().InitFieldCards();
        GameObject.Find("InfluencePlates").GetComponent<InfluencePlates>().ShowOrHideAll(true);
    }
    //加特使物件
    [ClientRpc]
    public void SetEmployeeClientRpc(string color, int areaNum)
    {
        if(!IsOwner) return;
        GameObject.Find("Employees").GetComponent<Employees>().SpawnEmployee(areaNum, color);
    }
    //清除特使
    [ClientRpc]
    public void ClearEmployeesClientRpc()
    {
        if(!IsOwner) return;
        GameObject.Find("Employees").GetComponent<Employees>().ClearEmployees();
    }
    //加soldier物件
    [ClientRpc]
    public void SetSoldierClientRpc(string type, string color, string movement, int num)
    {
        if(!IsOwner) return;
        if(movement == "spawn"){
            for(int i = 0; i < num; i++){
                GameObject.Find("Soldiers").GetComponent<Soldiers>().SpawnSoldier(type, color);
            }
        }else if(movement == "moveOut"){
            for(int i = 0; i < num; i++){
                GameObject.Find("Soldiers").GetComponent<Soldiers>().MoveToBattleField(type, color);
            }
        }else if(movement == "moveIn"){
            for(int i = 0; i < num; i++){
                GameObject.Find("Soldiers").GetComponent<Soldiers>().MoveToCamp(type, color);
            }
        }
        else{
            string status;
            if(movement == "despawnIn") status = "in";
            else status = "out";
            for(int i = 0; i < num; i++){
                GameObject.Find("Soldiers").GetComponent<Soldiers>().DespawnSoldier(type, color, status);
            }
        }
    }
    //衝突卡
    [ClientRpc]
    public void SetConflictCardClientRpc(int lvl, int conflictCardNum){
        if(!IsOwner) return;
        GameObject.Find("ConflictCards").GetComponent<ConflictCards>().SetConflictCards(lvl, conflictCardNum);
    }
    //牌庫卡
    [ClientRpc]
    public void SetCardsMarketClientRpc(int first, int second, int third, int fourth, int fifth)
    {
        if(!IsOwner) return;
        GameObject.Find("CardsMarket").GetComponent<CardsMarket>().CardsInMarketUpdate(new List<int>{first, second, third, fourth, fifth});
    }
    //運艘艦
    [ClientRpc]
    public void SetShip_MPlatesClientRpc(string color, int pos)
    {
        if(!IsOwner) return;
        GameObject.Find("Ship_MPlates").GetComponent<Ship_MPlates>().SetShip_MPlate(color, pos);
    }
    //影響力方塊
    [ClientRpc]
    public void SetInfluenceBlockClientRpc(string color, string type, int pos){
        if(!IsOwner) return;
        GameObject.Find("Influence").GetComponent<Influence>().SetInfluenceBlock(color, type, pos);
    }
    //分數圓柱
    [ClientRpc]
    public void SetScorePlateClientRpc(string color, int pos){
        if(!IsOwner) return;
        GameObject.Find("ScorePlates").GetComponent<ScorePlates>().SetScorePlate(color, pos);
    }
    //戰鬥標記
    [ClientRpc]
    public void SetCombatBlockClientRpc(string color, int pos){
        if(!IsOwner) return;
        GameObject.Find("CombatBlocks").GetComponent<CombatBlocks>().SetCombatBlock(color, pos);
    }
    //場上科技
    [ClientRpc]
    public void SetTechCardsClientRpc(int first, int second, int third){
        if(!IsOwner) return;
        TechCards techCards = GameObject.Find("TechCards").GetComponent<TechCards>();
        techCards.SetTechCards(0, first);
        techCards.SetTechCards(1, second);
        techCards.SetTechCards(2, third);
    }
    //自己的科技
    [ClientRpc]
    void AddSelfTechClientRpc(int techNum)
    {
        GameObject.Find("SelfTechs").GetComponent<SelfTechs>().AddTech(techNum);
    }
    [ClientRpc]
    void RemoveSelfTechClientRpc(int pos)
    {
        GameObject.Find("SelfTechs").GetComponent<SelfTechs>().RemoveTech(pos);
    }
    //場上牌
    [ClientRpc]
    void SpawnFieldCardsClientRpc(int pos, int cardNum){
        if(!IsOwner) return;
        GameObject.Find("FieldCards").GetComponent<FieldCards>().SpawnFieldCard(pos, cardNum);
    }
    [ClientRpc]
    void KickFieldCardsClientRpc(int pos){
        if(!IsOwner) return;
        GameObject.Find("FieldCards").GetComponent<FieldCards>().RemoveFieldCards(pos);
    }
    //影響力分數盤
    [ClientRpc]
    public void TakeInfluencePlateClientRpc(int alliance)
    {
        if(!IsOwner) return;
        GameObject.Find("InfluencePlates").GetComponent<InfluencePlates>().TakeAlliancePlate(alliance);
    }
    //香料
    /// <summary>
    /// movement => 0: clear, 1: addone
    /// </summary>
    [ClientRpc]
    public void SetSpiceClientRpc(int movement, int pos)
    {
        if(!IsOwner) return;
        if(movement == 0){
            GameObject.Find("Spices").GetComponent<Spices>().ClearSpice(pos);
        }else{
            GameObject.Find("Spices").GetComponent<Spices>().AddOneSpice(pos);
        }
        
    }
    
    #endregion 關於場上物件的資料傳遞
    [ClientRpc]
    void SetResourceUIClientRpc(string name, int num){
        if(!IsOwner) return;
        GameObject.Find("ShowUI").GetComponent<ShowUI>().ResourceNumberChange(name, num);
    }

    #endregion in game
    //玩家離開前
    public override void OnNetworkDespawn()
    {
        base.OnNetworkDespawn();
        if(!IsServer) return;
        playerController.PlayerLeave(gameObject.GetComponent<Player>());
    }

}