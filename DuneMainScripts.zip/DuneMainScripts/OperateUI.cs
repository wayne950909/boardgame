using System.Collections;
using System.Collections.Generic;
using System;
using UnityEngine.UI;
using UnityEngine;
using TMPro;

public class OperateUI : MonoBehaviour
{
    [SerializeField] GameObject backGround;
    [SerializeField] Button yesBtn;
    [SerializeField] Button noBtn;
    [SerializeField] Button thisBtn1;
    [SerializeField] Button thisBtn2;
    [SerializeField] TextMeshProUGUI text;
    [SerializeField] Button upBtn;
    [SerializeField] Button downBtn;
    [SerializeField] Button whiteBtn;
    [SerializeField] Button redBtn;
    [SerializeField] Button purpleBtn;
    [SerializeField] Button blueBtn;
    
    
    [SerializeField] Button finishBtn;
    [SerializeField] Button showBtn;
    [SerializeField] Button changeCardBtn;

    RectTransform rectTransform;
    //打開時應該在的位置
    Vector2 originPos = new Vector2(-250f, -180f);
    Vector2 goal;
    
    Bridge bridge;

    //防止選單被點兩次
    bool canBeClick = false;
    //重複做幾次
    public int number;

    void Awake()
    {
        bridge = GameObject.Find("Bridge").GetComponent<Bridge>();
        rectTransform = backGround.GetComponent<RectTransform>();
        goal = originPos;
    }
    void Start()
    {
        yesBtn.onClick.AddListener(() => {OnClick("YesOrNo", 1);});
        noBtn.onClick.AddListener(() => {OnClick("choose", 0);});
        thisBtn1.onClick.AddListener(() => {OnClick("choose", 1);});
        thisBtn2.onClick.AddListener(() => {OnClick("choose", 2);});
        upBtn.onClick.AddListener(() => {OnClick("upOrDown", 0);});
        downBtn.onClick.AddListener(() => {OnClick("upOrDown", 1);});
        whiteBtn.onClick.AddListener(() => {OnClick("influence", 0);});
        redBtn.onClick.AddListener(() => {OnClick("influence", 1);});
        purpleBtn.onClick.AddListener(() => {OnClick("influence", 2);});
        blueBtn.onClick.AddListener(() => {OnClick("influence", 3);});
        showBtn.onClick.AddListener(ShowBtnOnClick);
        finishBtn.onClick.AddListener(FinishBtnOnClick);
        changeCardBtn.onClick.AddListener(ChangeCardBtnOnClick);
        HideAllInBackGround();
        Close();
    }
    void OnClick(string type, int i)
    {
        number--;
        if(canBeClick){
            bridge.clientPlayer.ReplyServerRpc(type, i);
            if(number == 0) canBeClick = false;
        }
        if(number == 0) Close();
    }
    void ShowBtnOnClick()
    {
        bridge.clientPlayer.ShowCardsServerRpc();
    }
    void FinishBtnOnClick()
    {
        bridge.clientPlayer.FinishBtnOnClickServerRpc();
    }
    void ChangeCardBtnOnClick()
    {
        bridge.clientPlayer.ChangeCardsServerRpc();
    }


    void Update()
    {
        MovementUpdate();
    }
    void MovementUpdate()
    {
        if(Input.GetKeyDown(KeyCode.UpArrow)) {
            Close();
        }
        if(Input.GetKeyDown(KeyCode.DownArrow)) {
            Open();
        }
        if(rectTransform.anchoredPosition.y < goal.y){
            rectTransform.anchoredPosition += new Vector2(0, 1000f) * Time.deltaTime;
            if(rectTransform.anchoredPosition.y > goal.y) rectTransform.anchoredPosition = goal;
        }
        else if(rectTransform.anchoredPosition.y > goal.y){
            rectTransform.anchoredPosition -= new Vector2(0, 1000f) * Time.deltaTime;
            if(rectTransform.anchoredPosition.y < goal.y) rectTransform.anchoredPosition = goal;
        }
    }
    public void Close()
    {
        goal = originPos + new Vector2(0, 365f);
    }
    public void Open()
    {
        goal = originPos;
    }
    //隱藏所有選單上的元素
    void HideAllInBackGround()
    {
        for(int i = 0; i < backGround.transform.childCount; i++){
            backGround.transform.GetChild(i).gameObject.SetActive(false);
        }
    }
    /// <summary>
    /// 回應在ReplyServerRpc，type => YesOrNo, This1, This2, Tspecial4, soldierOrShip, soldierNumber, shipNumber, withdraw, upOrDown, influence
    /// </summary>
    public void SetOptions(string Text, string type, int num, int fontSize)
    {
        canBeClick = true;
        HideAllInBackGround();
        text.gameObject.SetActive(true);
        text.text = Text;
        text.fontSize = fontSize;
        number = num;
        switch(type){
            case "YesOrNo":
                yesBtn.gameObject.SetActive(true);
                noBtn.gameObject.SetActive(true);
                break;
            case "This1":
                noBtn.gameObject.SetActive(true);
                thisBtn1.gameObject.SetActive(true);
                break;
            case "This2":
                noBtn.gameObject.SetActive(true);
                thisBtn1.gameObject.SetActive(true);
                thisBtn2.gameObject.SetActive(true);
                break;
            case "Tspecial4":
                thisBtn1.gameObject.SetActive(true);
                thisBtn2.gameObject.SetActive(true);
                break;
            case "upOrDown":
                upBtn.gameObject.SetActive(true);
                downBtn.gameObject.SetActive(true);
                break;
            case "influence":
                whiteBtn.gameObject.SetActive(true);
                redBtn.gameObject.SetActive(true);
                purpleBtn.gameObject.SetActive(true);
                blueBtn.gameObject.SetActive(true);
                break;
            case "text":
                canBeClick = false; break;
        }
        Open();
    }
    public void FillPlayerNumber()
    {
        //略
    }
}
