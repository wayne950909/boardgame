using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using Unity.Netcode;
using Cards;
using System;
using UnityEngine.UIElements;

public class PlayerController : MonoBehaviour, ISaveAndLoad
{
    class GameData{
        public bool isGameStart = false;
        public List<int> empireCardsIG;
        public List<int> secretCardsIG;
        public List<int> conflictCardsIG;
        public List<int> techCards1;
        public List<int> techCards2;
        public List<int> techCards3;
        public int[] spice = new int[3]{0,0,0};
        public int startingPlayer;
        public int whoseTurn = 1;
        public bool isBlackEmployeeTaken;
        public int blackEmployeeCountDown;
        public List<int> allianceTakenScore = new List<int>{0,0,0,0};
        /// <summary>
        /// normal, combat, endGame
        /// </summary>
        public string roundStatus;
        public bool isRoundEnd;
    }

    public List<NormalCards> initialCards = InitialCards.GetInitialCards;
    public List<NormalCards> empireCards = EmpireCards.GetEmpireCards;
    public List<ConfliCtCards> conflictCards = ConfliCtCard.GetConflictCards;
    public List<SecretCards> secretCards = SecretCard.GetSecretCards;
    public List<TestCards> testCards = TestCard.GetTestCards;
    GameData gameData;
    List<Player> players = new List<Player>();
    public bool isReadyToStart = false;

    void Awake(){
        Load();
    }

    #region join and leave
    //bool => 是否成功加入
    public bool PlayerJoin(Player player, int number)
    {
        players.Add(player);
        //紀錄在List中的位置
        player.playersIndex = players.Count - 1;

        //是否準備好
        if(players.Count == 4) isReadyToStart = true;

        return true;
    }
    //玩家離開前執行
    public void PlayerLeave(Player player)
    {
        players.RemoveAt(player.playersIndex);

        //後面玩家index要-1
        foreach(var each in players)
        {
            if(each.playersIndex > player.playersIndex) each.playersIndex --;
        }
    }
    #endregion join and leave

    #region file
    //存檔
    public void Save()
    {
        File.WriteAllText(Application.dataPath + $"/Save/GameData.json", JsonUtility.ToJson(gameData));
    }
    //載入
    public void Load()
    {
        if(!File.Exists(Application.dataPath + $"/Save/GameData.json")){
            NewData();
        }
        gameData = JsonUtility.FromJson<GameData>(File.ReadAllText(Application.dataPath + $"/Save/GameData.json"));
    }
    //重置檔案
    public void NewData()
    {
        gameData = new GameData();
        Save();
    }
    //重置所有檔案
    public void NewGameData()
    {
        NewData();
        Load();
        for(int i = 1; i <= 4; i++)
        {
            File.WriteAllText(Application.dataPath + $"/Save/Player{i}Data.json", JsonUtility.ToJson(new Player.PlayerData()));
        }
        foreach(var player in players){
            player.NewData();
        }
    }
    #endregion file
    
    #region gamestart
    //遊戲開始初始
    public void Init()
    {
        gameData.startingPlayer = 1;
        gameData.isRoundEnd = false;
        gameData.roundStatus = "normal";
        //決定玩家順序
        var order = Movement.Wash(new List<int>{1, 2, 3, 4});
        foreach(var player in players){
            player.PlayerControllerGiveNumber(order[player.playersIndex]);
            player.Load();
        }
        //分配玩家棋子顏色
        var color = Movement.Wash(new List<string>{"blue", "yellow", "green", "red"});
        foreach(var player in players){
            player.PlayerControllerGiveColor(color[player.playersIndex]);
        }
        //生成牌
        gameData.empireCardsIG = Movement.Wash(Movement.CreateEmpireCards());
        gameData.secretCardsIG = Movement.Wash(Movement.CreateSecretCards());
        var techCards = Movement.Wash(Movement.CreateTechCards());
        gameData.techCards1 = techCards.GetRange(0, 6);
        gameData.techCards2 = techCards.GetRange(6, 6);
        gameData.techCards3 = techCards.GetRange(12, 6);
        gameData.conflictCardsIG = Movement.CreateConflictCards();
        //各種物件初始生成
        foreach(var player in players){
            player.InitObjectsClientRpc();
        }
        //衝突牌初始設置
        GivePlayersConflictCardData(conflictCards[gameData.conflictCardsIG[1]].level, gameData.conflictCardsIG[0]);
        //牌庫初始設置
        GivePlayerCardsInMarket();
        //科技初始設置
        GivePlayerTechCardData(gameData.techCards1[0], gameData.techCards2[0], gameData.techCards3[0]);
        //遊戲開始
        gameData.isGameStart = true;
        //黑特使初始
        gameData.isBlackEmployeeTaken = false;
    }
    //遊戲開始(包含reload)
    public void GameStart()
    {
        if(isReadyToStart){
            //如果沒開始過，就要先初始
            if(!gameData.isGameStart){
                Debug.Log("start");
                Init();
                foreach(var each in players) each.GameInit();
                //之後要加遊戲開始(在選角之後)
            }
            else{
                //檢查是否四位不同號碼
                var numbers = new List<int>();
                foreach(var each in players) numbers.Add(each.number);
                if(!(numbers.Contains(1) && numbers.Contains(2) && numbers.Contains(3) && numbers.Contains(4))) return;
                foreach(var each in players){
                    //先清除所有人的物件
                    each.ClearObjectsClientRpc();
                    //初始物件
                    each.InitObjectsClientRpc();
                    //衝突牌初始設置    
                    GivePlayersConflictCardData(conflictCards[gameData.conflictCardsIG[1]].level, gameData.conflictCardsIG[0]);
                    //牌庫初始設置
                    GivePlayerCardsInMarket();
                    //科技初始設置
                    GivePlayerTechCardData(gameData.techCards1[0], gameData.techCards2[0], gameData.techCards3[0]);
                    //每個玩家會給其他玩家資料
                    each.LoadIfGameHasStarted();
                    //給玩家香料資料
                    for(int i = 0; i < 3; i++)
                        for(int j = 0; j < gameData.spice[i]; j++)
                            GivePlayerSpiceData(1, i);
                    //給影響力圓盤資料
                    int alliance = 0;
                    foreach(var eachScore in gameData.allianceTakenScore){
                        if(eachScore != 0){
                            foreach(var player in players){
                                player.TakeInfluencePlateClientRpc(alliance);
                            }
                        }
                        alliance++;
                    }
                }
            }
            //load完，直接呼叫玩家開始回合
            CallPlayerTurn(gameData.whoseTurn);
        }
    }
    #endregion gamestart
    
    #region in game
    //告知所有player誰的回合
    void CallPlayerTurn(int num)
    {
        foreach(var each in players){
            each.PlayerControllerCallPlayerTurn(num);
        }
    }
    void NextPlayer()
    {
        if(gameData.whoseTurn == 4) gameData.whoseTurn = 1;
        else gameData.whoseTurn ++;
        //如果回合結束就不必再call
        if(gameData.roundStatus == "normal"){
            foreach(var player in players){
                if(player.number == gameData.whoseTurn){
                    if(player.playerData.roundFinished){
                        NextPlayer();
                    }
                }
            }
        }
    }
    void RoundStart()
    {
        gameData.isRoundEnd = false;
        gameData.roundStatus = "normal";
        if(gameData.startingPlayer == 4) gameData.startingPlayer = 1;
        else gameData.startingPlayer++;
        gameData.whoseTurn = gameData.startingPlayer;
        foreach(var player in players){
            player.RoundInit();
        }
        //黑特使倒數
        if(gameData.blackEmployeeCountDown > 0){
            gameData.blackEmployeeCountDown--;
            if(gameData.blackEmployeeCountDown == 0){
                gameData.isBlackEmployeeTaken = false;
            }
        }
    }
    //player結束回合要呼叫
    public void PlayerTurnFinished()
    {
        if(gameData.roundStatus != "combat"){
            //正常回合結束判定
            gameData.isRoundEnd = true;
            foreach(var player in players){
                if(!player.playerData.roundFinished) gameData.isRoundEnd = false;
            }
            if(gameData.isRoundEnd){
                //戰鬥回合開始
                //戰鬥密牌
                gameData.roundStatus = "combat";
                foreach(var player in players){
                    //先加上為加上的combat
                    player.CountCombat();
                    player.playerData.combatRoundFinished = false;
                }
                gameData.whoseTurn = gameData.startingPlayer;
            }else{
                //正常回合繼續
                NextPlayer();
            }
        }else{
            //戰鬥密牌回合繼續
            NextPlayer();
            //密牌回合結束判定
            bool isEveryonePass = true;
            foreach(var player in players){
                if(!player.playerData.combatRoundFinished) isEveryonePass = false;
            }
            if(isEveryonePass && gameData.whoseTurn == gameData.startingPlayer){
                //戰鬥
                Combat();
                //檢查遊戲是否結束
                bool ifGameEnd = false;
                foreach(var player in players){
                    if(player.playerData.score >= 10) ifGameEnd = true;
                }
                if(ifGameEnd){
                    //終局密牌
                    gameData.roundStatus = "endGame";
                    foreach(var player in players){
                        foreach(var eachCard in player.playerData.secretCards){
                            SecretCards secretCard = secretCards[eachCard];
                            if(secretCard.type == "endGame" || secretCard.type == "normalOrEndGame" || secretCard.type == "combatOrEndGame"){
                                player.PlayerControllerCallDoEffection(secretCard.effection);
                            }
                        }
                    }
                    //終局最後加分
                    foreach(var player in players){
                        int addScore = player.playerData.spiceNum/10;
                        player.PlayerControllerCallDoEffection(Effection.Gain("score", addScore));
                        player.PlayerControllerCallDoEffection(Effection.Gain("spice", addScore*-10));
                    }
                    //誰贏
                    int highestScore = 0;
                    List<int> theFirstIndex = new List<int>();
                    foreach(var player in players){
                        if(player.playerData.score > highestScore){
                            highestScore = player.playerData.score;
                            theFirstIndex.Clear();
                            theFirstIndex.Add(player.playersIndex);
                        }else if(player.playerData.score == highestScore){
                            theFirstIndex.Add(player.playersIndex);
                        }
                    }
                    foreach(var each in theFirstIndex){
                        players[each].WhoseTurnTextClientRpc("You Win!");
                    }
                }else{
                    //補香料，檢查16-18地區
                    for(int i = 16; i <= 18; i++){
                        bool beGone = false;
                        foreach(var player in players){
                            if(player.playerData.areas.Contains(i)){
                                beGone = true;
                                break;
                            }
                        }
                        if(!beGone){
                            gameData.spice[i-16]++;
                            GivePlayerSpiceData(1, i-16);
                        }
                    }
                    //新的回合
                    RoundStart();
                }
            }
        }

        //存檔
        Save();
        foreach(ISaveAndLoad each in players)
        {
            each.Save();
        }
        //呼叫玩家回合
        CallPlayerTurn(gameData.whoseTurn);
    }
    //戰鬥
    void Combat()
    {
        //戰鬥
        int theFirst = -1;
        List<int> theSecond = new List<int>();
        List<int> theThird = new List<int>();

        List<int> order = new List<int>();
        List<int> combat = new List<int>();
        //排序 order and combat
        foreach(var player in players){
            if(player.playerData.combat == 0) continue;
            if(order.Count == 0){
                order.Add(player.playersIndex);
                combat.Add(player.playerData.combat);
                continue;
            }
            for(int i = 0; i < order.Count; i++)
            {
                if(player.playerData.combat >= combat[i]){
                    order.Insert(i, player.playersIndex);
                    combat.Insert(i, player.playerData.combat);
                    break;
                }
                if(i == order.Count-1){
                    order.Add(player.playersIndex);
                    combat.Add(player.playerData.combat);
                    break;
                }
            }
        }
        int repeatTimes = 0;
        int highestRank = 0;
        for(int i = 0; i < combat.Count; i++)
        {
            if(i != combat.Count-1){
                if(combat[i] == combat[i+1]){
                    repeatTimes++;
                    continue;
                }
            }
            for(int j = 0; j < repeatTimes+1; j++){
                if(highestRank + repeatTimes == 0) theFirst = order[i];
                else if(highestRank + repeatTimes == 1) theSecond.Add(order[i-j]);
                else if(highestRank + repeatTimes == 2) theThird.Add(order[i-j]);
            }
            highestRank++;
        }
        //戰鬥獎勵
        ConfliCtCards conflictCard = conflictCards[gameData.conflictCardsIG[0]];
        if(theFirst != -1) players[theFirst].PlayerControllerGiveCombatReward(conflictCard.effection1st);
        foreach(var each in theSecond) players[each].PlayerControllerGiveCombatReward(conflictCard.effection2nd);
        foreach(var each in theThird) players[each].PlayerControllerGiveCombatReward(conflictCard.effection3rd);
        //換牌
        gameData.conflictCardsIG.RemoveAt(0);
        GivePlayersConflictCardData(conflictCards[gameData.conflictCardsIG[1]].level, gameData.conflictCardsIG[0]);
    }
    //得知回合狀態
    public string GetRoundStatus(){
        return gameData.roundStatus;
    }
    //拿黑特使
    public bool TakeBlackEmployee()
    {
        if(!gameData.isBlackEmployeeTaken){
            gameData.isBlackEmployeeTaken = true;
            gameData.blackEmployeeCountDown = 2;
            return true;
        }else{
            return false;
        }
    }
    //拿圓盤 alliance => 0-3
    public void TakeAllianceScore(string color, int alliance, int num)
    {
        if(gameData.allianceTakenScore[alliance] == 0){
            gameData.allianceTakenScore[alliance] = num;
        }else if(gameData.allianceTakenScore[alliance] < num){
            gameData.allianceTakenScore[alliance] = num;
            GiveOrRemovePlayerAllianceScore(color, alliance);
        }
    }
    //拿香料
    public int TakeSpice(int areaNum)
    {
        int num = gameData.spice[areaNum-16];
        gameData.spice[areaNum-16] = 0;
        GivePlayerSpiceData(0, areaNum-16);
        return num;
    }
    void GiveOrRemovePlayerAllianceScore(string color, int alliance)
    {
        foreach(var player in players){
            player.PlayerControllerGiveAllianceScore(color, alliance);
        }
    }
    //抽密牌 return 牌編號
    public int DrawSecretCards()
    {
        int cardNum = gameData.secretCardsIG[0];
        gameData.secretCardsIG.RemoveAt(0);
        return cardNum;
    }
    //科技
    public int GetTech(int pos)
    {
        if(pos == 0){
            return gameData.techCards1[0];
        }else if(pos == 1){
            return gameData.techCards2[0];
        }else{
            return gameData.techCards3[0];
        }
    }
    public void BuyTech(int pos)
    {
        if(pos == 0){
            gameData.techCards1.RemoveAt(0);
        }else if(pos == 1){
            gameData.techCards2.RemoveAt(0);
        }else{
            gameData.techCards3.RemoveAt(0);
        }
        GivePlayerTechCardData(gameData.techCards1[0], gameData.techCards2[0], gameData.techCards3[0]);
    }
    /// <summary>
    /// 買牌
    /// </summary>
    /// <param name="pos">0-4</param>
    public void BuyCard(int pos){
        gameData.empireCardsIG.RemoveAt(pos);
        GivePlayerCardsInMarket();
    }
    #region 放送物件資訊給玩家
    /// <summary>
    /// 給所有玩家特使資訊
    /// </summary>
    public void GivePlayersEmployeeData(string color, int area)
    {
        foreach(var each in players){
            each.SetEmployeeClientRpc(color, area);
        }
    }
    /// <summary>
    /// 給所有玩家soldier資訊 movement => spawn, moveIn, moveOut, despawnIn, despawnOut
    /// </summary>
    public void GivePlayersSoldierData(string type, string color, string movement, int num)
    {
        foreach(var player in players){
            player.SetSoldierClientRpc(type, color, movement, num);
        }
    }
    //給衝突卡
    public void GivePlayersConflictCardData(int lvl, int conflictCardNum){
        foreach(var player in players){
            player.SetConflictCardClientRpc(lvl, conflictCardNum);
        }
    }
    //給場上牌庫
    void GivePlayerCardsInMarket(){
        foreach(var player in players){
            player.SetCardsMarketClientRpc(gameData.empireCardsIG[0], gameData.empireCardsIG[1], gameData.empireCardsIG[2], gameData.empireCardsIG[3], gameData.empireCardsIG[4]);
        }
    }
    //給運送船
    public void GivePlayerShip_MPlateData(string color, int pos){
        foreach(var player in players){
            player.SetShip_MPlatesClientRpc(color, pos);
        }
    }
    //給影響力方塊
    public void GivePlayerInfluenceBlockData(string color, string type, int pos){
        foreach(var player in players){
            player.SetInfluenceBlockClientRpc(color, type, pos);
        }
    }
    //給分數圓柱
    public void GivePlayerScorePlateData(string color, int pos)
    {
        foreach(var player in players){
            player.SetScorePlateClientRpc(color, pos);
        }
    }
    //給戰鬥標記
    public void GivePlayerCombatBlockData(string color, int pos){
        foreach(var player in players){
            player.SetCombatBlockClientRpc(color, pos);
        }
    }
    //給科技牌
    public void GivePlayerTechCardData(int first, int second, int third){
        foreach(var player in players){
            player.SetTechCardsClientRpc(first, second, third);
        }
    }
    //給圓盤
    public void GivePlayerAllianceScoreData()
    {
        foreach(var player in players){
            
        }
    }
    /// <summary>
    /// 給香料 movement => 0: clear, 1: addone
    /// </summary>
    public void GivePlayerSpiceData(int movement, int pos)
    {
        foreach(var player in players){
            player.SetSpiceClientRpc(movement, pos);
        }
    }
    #endregion 放送物件資訊給玩家
    
    //傳回一個還可以去的地方的list
    public List<int> GetAvailableAreas()
    {
        var areas = new List<int>{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22};
        foreach(var each in players){
            foreach(var eachNum in each.playerData.areas){
                if(areas.Contains(eachNum)){
                    areas.Remove(eachNum);
                }
            }
        }
        return areas;
    }
    #endregion in game
}
