using System.Collections;
using System.Collections.Generic;
using Unity.Netcode;
using UnityEngine.UI;
using UnityEngine;
using TMPro;

public class Join : MonoBehaviour
{
    [SerializeField] TMP_InputField joinCodeInputField;
    [SerializeField] TMP_InputField playerNumber;
    [SerializeField] Button beHostBtn;
    [SerializeField] Button joinBtn;
    [SerializeField] TextMeshProUGUI errorText;

    [SerializeField] GameObject playerController;
    // Start is called before the first frame update
    void Start()
    {
        errorText.gameObject.SetActive(false);
        joinBtn.onClick.AddListener(() => {OnClick(false);});
        beHostBtn.onClick.AddListener(() => {OnClick(true);});
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    void Show()
    {
        gameObject.SetActive(true);
    }
    void Hide()
    {
        gameObject.SetActive(false);
    }
    //輸入的玩家號碼暫存位置
    public int playerNum = 0;
    void OnClick(bool isHost)
    {
        Hide();
        if(playerNumber.text == "") playerNum = 0;
        else playerNum = int.Parse(playerNumber.text);
        if(isHost){
            NetworkManager.Singleton.StartHost();
            GameObject gameObject = Instantiate(playerController);
            gameObject.name = "PlayerController";
        }
        else
            NetworkManager.Singleton.StartClient();
    }
}
