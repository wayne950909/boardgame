using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerCamera : MonoBehaviour
{
    public List<ISelectable> iSelectables = new List<ISelectable>();
    Ray ray;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if(Input.GetMouseButtonDown(0)){
            //射線
            ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            RaycastHit hit;
            //Selectalbe
            if(Physics.Raycast(ray, out hit, Mathf.Infinity, 1 << 3)){
                hit.collider.gameObject.GetComponent<ISelectable>().Selected();
            }
            //將所有ISelectable物件放下
            foreach(var each in iSelectables) each.CancelSelected();
        }
    }
    
}
